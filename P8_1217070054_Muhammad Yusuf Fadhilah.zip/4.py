#Muhammad Yusuf Fadhilah
#1217070054

import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread("C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/4/gura.jpeg")

gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

fourier = cv2.dft(np.float32(gray), flags=cv2.DFT_COMPLEX_OUTPUT)

fourier_shift = np.fft.fftshift(fourier)

magnitude = 20*np.log(cv2.magnitude(fourier_shift[:,:,0], fourier_shift[:,:,1]))

plt.imshow(magnitude)
plt.show()
plt.waitforbuttonpress()
plt.close('all')