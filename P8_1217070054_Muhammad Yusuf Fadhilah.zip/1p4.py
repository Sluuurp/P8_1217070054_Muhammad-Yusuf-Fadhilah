#Muhammad Yusuf Fadhilah
#1217070054

import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread("C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/4/gura.jpeg")

gura = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

plt.imshow(img)
plt.show

kernel = np.matrix([
         [1, 1,1],
         [1, 2, 1],
         [1, 1, 1]
         ])/2

print(kernel)

guraalt = cv2.filter2D(img, -1, kernel)

plt.imshow(guraalt)
plt.waitforbuttonpress()
plt.close('x')