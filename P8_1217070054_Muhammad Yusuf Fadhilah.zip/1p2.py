#Muhammad Yusuf Fadhilah
#1217070054

import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread("C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/4/gura.jpeg")
gura = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

kernel = np.ones((5,5), np.float32)/25

guraalt = cv2.filter2D(img, -1, kernel)

plt.rcParams["figure.figsize"] = (15,15)

plt.subplot(121), plt.imshow(gura), plt.title('Original')
plt.xticks([]), plt.yticks([])

plt.subplot(122), plt.imshow(guraalt)
plt.title('Averaging')
plt.xticks([])

plt.show
plt.waitforbuttonpress()
plt.close('x')