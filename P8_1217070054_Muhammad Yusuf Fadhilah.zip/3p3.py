#Muhammad Yusuf Fadhilah
#1217070054

import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread("C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/4/gura.jpeg", 0)

blur = cv2.GaussianBlur(img,(5,5),0)

ret3,th3 = cv2.threshold(blur,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)

plt.imshow(th3,'gray')
plt.show()
plt.waitforbuttonpress()
plt.close('all')